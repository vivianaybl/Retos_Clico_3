package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Reto3G33Application {

	public static void main(String[] args) {
		SpringApplication.run(Reto3G33Application.class, args);
	}

}
